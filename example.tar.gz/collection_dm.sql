drop table if exists collection_dm;
create table collection_dm (
  id int auto_increment primary key
  ,description varchar(40) not null
  ,default_flg char(1) not null
  ,days_due_back smallint unsigned not null
  ,daily_late_fee decimal(4,2) not null
);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Adult Fiction','N',21,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Adult Nonfiction','Y',21,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Cassettes','N',7,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Compact Discs','N',7,0.15);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Computer Software','N',7,0.15);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Easy Readers','N',21,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Juvenile Fiction','N',21,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Juvenile Nonfiction','N',21,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('New Books','N',14,0.10);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Periodics','N',14,0.05);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Reference','N',0,0.00);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Videos and DVDs','N',3,1.00);
insert into collection_dm (description, default_flg, days_due_back, daily_late_fee) values ('Digital Books','N',3,1.00);
