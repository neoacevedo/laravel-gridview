<?php

namespace App\Http\Controllers;

use App\Models\CollectionDm;
use App\Models\User;
use DB;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\View;

class SiteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function asComponent(Request $request, int $page = 1, int $perPage = 5)
    {
        // 
        $orderBy = "id";
        $sort = 'ASC';

        if ($request->get('sort') !== null) {
            if (substr($request->get('sort'), 0, 1) === '-') {
                $orderBy = substr($request->get('sort'), 1);
                $sort = 'DESC';
            } else {
                $orderBy = $request->get('sort');
                $sort = 'ASC';
            }
        }
        $dataProvider = CollectionDm::orderBy($orderBy, $sort)
            ->paginate(5);

        return response()->view('site.component', compact('dataProvider'));
    }

    public function asClass()
    {
        $data = [
            [
                'nombre' => 'Andres',
                'fecha' => 1706200888,
                'email' => 'andres@localhost.com',
            ],
            [
                'nombre' => 'Jorge',
                'fecha' => 1706200890,
                'email' => 'jorge@localhost.com',
            ],
            [
                'nombre' => 'Nelson',
                'fecha' => 1706200990,
                'email' => 'nilson@localhost.com',
            ],
            [
                'nombre' => 'Juan',
                'fecha' => 1706201000,
                'email' => 'juan@localhost.com',
            ],
            [
                'nombre' => 'Pedro',
                'fecha' => 1706201010,
                'email' => 'pedro@localhost.com',
            ],
            [
                'nombre' => 'Felipe',
                'fecha' => 1706201020,
                'email' => 'felipe@localhost.com',
            ],
            [
                'nombre' => 'Fredy',
                'fecha' => 1706201030,
                'email' => 'fredy@localhost.com',
            ],
            [
                'nombre' => 'Richard',
                'fecha' => 1706201040,
                'email' => 'richard@localhost.com',
            ],
        ];

        Collection::macro('paginate', function ($perPage, $total = null, $page = null, $pageName = 'page') {
            $page = $page ?: LengthAwarePaginator::resolveCurrentPage($pageName);

            return new LengthAwarePaginator($this->forPage($page, $perPage), $total ?: $this->count(), $perPage, $page, [
                'path' => LengthAwarePaginator::resolveCurrentPath(),
                'pageName' => $pageName,
            ]);
        });

        $dataProvider = collect($data)->paginate(5);

        return response()->view('site.class', compact('dataProvider'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $dataProvider = [
            [
                'nombre' => 'Andres',
                'fecha' => 1706200888,
                'email' => 'andres@localhost.com',
            ],
            [
                'nombre' => 'Jorge',
                'fecha' => 1706200890,
                'email' => 'jorge@localhost.com',
            ],
            [
                'nombre' => 'Nilson',
                'fecha' => 1706200990,
                'email' => 'nilson@localhost.com',
            ],
            [
                'nombre' => 'Juan',
                'fecha' => 1706201000,
                'email' => 'juan@localhost.com',
            ],
            [
                'nombre' => 'Pedro',
                'fecha' => 1706201010,
                'email' => 'pedro@localhost.com',
            ],
            [
                'nombre' => 'Felipe',
                'fecha' => 1706201020,
                'email' => 'felipe@localhost.com',
            ],
            [
                'nombre' => 'Fredy',
                'fecha' => 1706201030,
                'email' => 'fredy@localhost.com',
            ],
        ];
        return response()->view('site.index', compact('dataProvider'));
    }

    public function search_component(Request $request)
    {
        $orderBy = "id";
        $sortMode = 'ASC';
        $sort = $request->get('sort');
        if ($sort !== null) {
            if (substr($sort, 0, 1) === '-') {
                $orderBy = substr($sort, 1);
                $sortMode = 'DESC';
            } else {
                $orderBy = $sort;
                $sortMode = 'ASC';
            }
        }

        $dataProvider = CollectionDm::where("id", $request->get('filter_id') !== null ? "=" : "!=", $request->get('filter_id'));

        if ($request->get('filter_description')) {
            $dataProvider = $dataProvider->where("description", 'like', '%' . $request->get('filter_description') . '%');
        }

        if ($request->get('filter_days_due_back')) {
            $dataProvider = $dataProvider->where("days_due_back", 'like', '%' . $request->get('filter_days_due_back') . '%');
        }

        $dataProvider = $dataProvider->orderBy($orderBy, $sortMode)
            ->paginate(5);

        return response()->view('site.component', compact('dataProvider'));
    }

    public function class_delete($id = 0)
    {
        return response()->redirectToIntended();
    }
}
